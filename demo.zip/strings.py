PROCESS_DONE_MESSAGE = """
✅ For {movie_name} {review_count} User Reviews recorded!

🔗 http://127.0.0.1:8000/?request_id={record_id}"""


HELP_COMMAND_RESPONSE = """
Hey there!
Using this bot is simple and convenient:
Just type: @imdbot YOUR_FILM_NAME

For example: @imdbot Inception

You can also send the movie name directly in a message, but that might take a bit more effort."""
